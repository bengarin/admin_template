(function($) {
	"use strict";
	
	//P-scrolling
	
	
	const ps2 = new PerfectScrollbar('#documenter_nav', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	
	
	
	
})(jQuery);