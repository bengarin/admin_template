---
title: App indicator
categories:
  - Apps
tags:
  - app
  - application
  - ios
  - android
  - notification
  - square
---
